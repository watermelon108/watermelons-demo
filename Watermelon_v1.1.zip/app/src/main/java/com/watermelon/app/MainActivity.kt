package com.watermelon.app

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.text.InputType
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var results: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var banner: TextView
    private val resultItems = mutableListOf<Pair<String, String>>()
    private var updateApkUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        results = findViewById(R.id.resultsList)
        banner = findViewById(R.id.updateBanner)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList<String>())
        results.adapter = adapter

        findViewById<Button>(R.id.searchBtn).setOnClickListener { runSearch() }
        findViewById<Button>(R.id.btnSearch).setOnClickListener { runSearch() }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { showSettings() }
        findViewById<Button>(R.id.btnLibrary).setOnClickListener { showLibrary() }
        findViewById<Button>(R.id.btnPlayer).setOnClickListener { askStreamUrl() }
        findViewById<Button>(R.id.btnDownload).setOnClickListener { askDownloadUrl() }
        findViewById<Button>(R.id.scraperChip).setOnClickListener { pickScraper() }
        banner.setOnClickListener { openUpdate() }

        results.setOnItemClickListener { _, _, pos, _ -> showItemActions(pos) }

        handleIntent(intent)
        refreshChip()
        checkUpdate(manual = false)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val data = intent?.data ?: return
        if (data.scheme == "wm") addScraperFromLink(data.toString())
    }

    private fun refreshChip() {
        val active = ScraperStore.activeScrapers(this)
        val sel = ScraperStore.selectedName(this)
        val label = when {
            active.isEmpty() -> "Scraper: none"
            active.size == 1 -> "Scraper: ${active[0].name}"
            else -> "Scraper: ${sel ?: active[0].name} (${active.size} on)"
        }
        findViewById<Button>(R.id.scraperChip).text = label
    }

    // ---------- Search (scrapers) ----------

    private fun runSearch() {
        val query = findViewById<EditText>(R.id.searchInput).text.toString().trim()
        if (query.isEmpty()) return
        val active = ScraperStore.activeScrapers(this)
        if (active.isEmpty()) {
            Toast.makeText(this, "Settings me scraper add karein", Toast.LENGTH_SHORT).show()
            return
        }
        val selected = ScraperStore.selectedName(this)
        val targets = if (active.size > 1 && selected != null) {
            active.filter { it.name == selected }
        } else {
            active
        }

        resultItems.clear()
        adapter.clear()
        adapter.notifyDataSetChanged()
        Toast.makeText(this, "Searching...", Toast.LENGTH_SHORT).show()

        for (s in targets) {
            val searchUrl = s.baseUrl.trimEnd('/') + s.searchPath.replace("{q}", Uri.encode(query))
            Thread {
                val html = Net.get(searchUrl)
                val found = if (html == null) emptyList() else Scraping.findMedia(html)
                runOnUiThread {
                    if (found.isEmpty()) {
                        Toast.makeText(this, "${s.name}: kuch nahi mila", Toast.LENGTH_SHORT).show()
                    }
                    for (u in found) {
                        val label = "$query\n[${s.name}]"
                        resultItems.add(Pair(label, u))
                        adapter.add(label)
                    }
                    adapter.notifyDataSetChanged()
                }
            }.start()
        }
    }

    private fun showItemActions(pos: Int) {
        val item = resultItems.getOrNull(pos) ?: return
        val options = arrayOf("Play", "Save to library", "Download")
        AlertDialog.Builder(this)
            .setTitle("Action chunein")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openPlayer(item.second, null)
                    1 -> pickTagAndSave(item)
                    2 -> download(item.second)
                }
            }
            .show()
    }

    private fun pickTagAndSave(item: Pair<String, String>) {
        val tags = LibraryStore.TAGS.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Tag chunein")
            .setItems(tags) { _, which ->
                LibraryStore.put(this, LibItem(item.second, item.first.replace("\n", " "), tags[which]))
                Toast.makeText(this, "Saved: ${tags[which]}", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    // ---------- Library ----------

    private fun showLibrary() {
        val tags = LibraryStore.TAGS.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Saved / Library")
            .setItems(tags) { _, which ->
                val items = LibraryStore.all(this).filter { it.tag == tags[which] }
                if (items.isEmpty()) {
                    Toast.makeText(this, "${tags[which]} me kuch nahi hai", Toast.LENGTH_SHORT).show()
                } else {
                    AlertDialog.Builder(this)
                        .setTitle(tags[which])
                        .setItems(items.map { it.title }.toTypedArray()) { _, idx ->
                            openPlayer(items[idx].url, null)
                        }
                        .show()
                }
            }
            .show()
    }

    // ---------- Downloader ----------

    private fun askDownloadUrl() {
        val input = EditText(this).apply { hint = "Direct video link (mp4/mkv/webm)" }
        AlertDialog.Builder(this)
            .setTitle("Download")
            .setView(input)
            .setPositiveButton("Download") { _, _ -> download(input.text.toString().trim()) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun download(url: String) {
        if (url.isEmpty()) return
        if (url.contains(".m3u8", ignoreCase = true)) {
            Toast.makeText(this, "M3U8 (HLS) download abhi supported nahi hai", Toast.LENGTH_LONG).show()
            return
        }
        val fileName = Uri.parse(url).lastPathSegment ?: "watermelon_video.mp4"
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle(fileName)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        dm.enqueue(request)
        Toast.makeText(this, "Download shuru: $fileName", Toast.LENGTH_SHORT).show()
    }

    // ---------- Player ----------

    private fun openPlayer(url: String, sub: String?) {
        val i = Intent(this, PlayerActivity::class.java)
            .putExtra(PlayerActivity.EXTRA_URL, url)
        if (!sub.isNullOrEmpty()) i.putExtra(PlayerActivity.EXTRA_SUB, sub)
        startActivity(i)
    }

    private fun askStreamUrl() {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val streamInput = EditText(this).apply { hint = "Stream link (m3u8 / mp4)" }
        val subInput = EditText(this).apply {
            hint = "Subtitle link (.srt/.vtt, optional)"
            inputType = InputType.TYPE_CLASS_TEXT
        }
        container.addView(streamInput)
        container.addView(subInput)
        AlertDialog.Builder(this)
            .setTitle("M3U8 / Network stream")
            .setView(container)
            .setPositiveButton("Play") { _, _ ->
                val sub = subInput.text.toString().trim()
                openPlayer(streamInput.text.toString().trim(), if (sub.isEmpty()) null else sub)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Settings / scrapers ----------

    private fun pickScraper() {
        val active = ScraperStore.activeScrapers(this)
        if (active.isEmpty()) {
            Toast.makeText(this, "Koi active scraper nahi hai", Toast.LENGTH_SHORT).show()
            return
        }
        val names = active.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Home scraper")
            .setItems(names) { _, which ->
                ScraperStore.setSelected(this, active[which].name)
                refreshChip()
            }
            .show()
    }

    private fun showSettings() {
        val options = arrayOf("Add scraper (paste Melon link)", "Manage scrapers (on/off, delete)", "Check for update", "About")
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> pasteMelonLink()
                    1 -> manageScrapers()
                    2 -> checkUpdate(manual = true)
                    3 -> Toast.makeText(this, "Watermelon v1.1.0", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun pasteMelonLink() {
        val input = EditText(this).apply {
            hint = "wm://add?cfg=..."
            inputType = InputType.TYPE_CLASS_TEXT
        }
        AlertDialog.Builder(this)
            .setTitle("Melon Codes link paste karein")
            .setView(input)
            .setPositiveButton("Add") { _, _ -> addScraperFromLink(input.text.toString()) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun addScraperFromLink(link: String) {
        val s = ScraperStore.parseMelonLink(link)
        if (s == null) {
            Toast.makeText(this, "Link galat hai", Toast.LENGTH_SHORT).show()
            return
        }
        ScraperStore.add(this, s)
        if (ScraperStore.selectedName(this) == null) ScraperStore.setSelected(this, s.name)
        refreshChip()
        Toast.makeText(this, "Scraper added: ${s.name}", Toast.LENGTH_SHORT).show()
    }

    private fun manageScrapers() {
        val list = ScraperStore.all(this)
        if (list.isEmpty()) {
            Toast.makeText(this, "Koi scraper nahi", Toast.LENGTH_SHORT).show()
            return
        }
        val names = list.map { (if (it.enabled) "[ON] " else "[OFF] ") + it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Scrapers (tap to on/off)")
            .setItems(names) { _, which ->
                val s = list[which]
                s.enabled = !s.enabled
                ScraperStore.save(this, list)
                refreshChip()
                manageScrapers()
            }
            .setNeutralButton("Delete last") { _, _ ->
                ScraperStore.remove(this, list.last().name)
                refreshChip()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------- Update ----------

    private fun checkUpdate(manual: Boolean) {
        Thread {
            val text = Net.get(Net.UPDATE_URL)
            var newCode = 0
            var newName = ""
            var apk = ""
            if (text != null) {
                try {
                    val j = JSONObject(text)
                    newCode = j.getInt("versionCode")
                    newName = j.optString("versionName")
                    apk = j.optString("apkUrl")
                } catch (e: Exception) {
                    // bad json, ignore
                }
            }
            val current = packageManager.getPackageInfo(packageName, 0).versionCode
            runOnUiThread {
                if (text == null) {
                    if (manual) Toast.makeText(this, "Update check fail: internet dekhein", Toast.LENGTH_SHORT).show()
                } else if (newCode > current && apk.isNotEmpty()) {
                    updateApkUrl = apk
                    banner.text = "Naya version $newName available. Yahan tap karke update karein"
                    banner.visibility = View.VISIBLE
                    if (manual) openUpdate()
                } else {
                    banner.visibility = View.GONE
                    if (manual) Toast.makeText(this, "Aap latest version par hain", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun openUpdate() {
        val url = updateApkUrl ?: return
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}
